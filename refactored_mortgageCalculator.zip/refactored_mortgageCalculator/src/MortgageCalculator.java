import java.text.NumberFormat;
import java.util.Scanner;

public class MortgageCalculator {
    //refactored_mortgageCalculator

        //REFACTORING CODE
        //refactoring is the change in code without changing its behaviour
        // refactoring help in code reusability and code readibility

        public static void main(String []arg){

            int AmountOfLoan =0;
            float AnnualInterestRate=0;
            int  Year = 0;

            //AmountOfLoan
            AmountOfLoan = (int)readNumber("Amount of loan",1000,1_000_000);
            //MonthlyinterestRate
            AnnualInterestRate = (float) readNumber("Annualinterst rate",1,30);
            Year = (int) readNumber("motragage time period",1,30);

            double mortgage = calculateMortgage(AmountOfLoan ,  AnnualInterestRate,   Year);

            String mortgageFormatted = NumberFormat.getCurrencyInstance().format(mortgage);
            System.out.println("Mortgage: " + mortgageFormatted);


        }

        public static double readNumber(String prompt,int min,int max){
            double value;
            while(true){
                Scanner scanner = new Scanner(System.in);
                System.out.println("Enter mortage period in year: ");
                value = scanner.nextInt();
                if(value>=min && value<=max)
                    break;
                System.out.println("please enter value greater between "+ min +" and " + max);  }
            return value;}



        public static double calculateMortgage(  int AmountOfLoan ,
                                                 float AnnualInterestRate,
                                                 int  Year)
        {    final int percent= 100;
            final int months = 12;
            float MonthlyinterestRate = AnnualInterestRate/percent/months;
            int NumberOfPayment = Year*months;
            double mortgage = AmountOfLoan
                    * (MonthlyinterestRate * Math.pow(1 + MonthlyinterestRate, NumberOfPayment))
                    / (Math.pow(1 + MonthlyinterestRate, NumberOfPayment) - 1);
            return mortgage;
        }
    }}


